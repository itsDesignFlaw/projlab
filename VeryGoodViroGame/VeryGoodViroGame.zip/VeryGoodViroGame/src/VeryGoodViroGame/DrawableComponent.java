package VeryGoodViroGame;

public interface DrawableComponent
{
    int x = 0, y = 0;
    
    String GetDrawString();
}
