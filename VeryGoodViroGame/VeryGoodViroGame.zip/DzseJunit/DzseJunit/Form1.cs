using System.Diagnostics;
using System.Globalization;

namespace DzseJunit
{
    public partial class Form1 : Form
    {
        private string resultPath = new string($@"..\..\..\..\VeryGoodViroGame\testfiles\in");
        public Form1()
        {
            InitializeComponent();

            listView1.Items.Clear();
            listView1.BackColor = Color.Black;
            listView1.ForeColor = Color.White;

            DirectoryInfo di = new DirectoryInfo(resultPath);
            try
            {
                foreach (FileInfo file in di.GetFiles())
                {
                    string temp = file.Name;
                    temp = temp.Replace('_', ' ');
                    temp = temp.Replace(".tin", "");

                    listView1.Items.Add(new ListViewItem(new String[] { temp, file.Name }));
                }
            }
            catch (DirectoryNotFoundException dnfe)
            {
                MessageBox.Show($"testfiles directory does not exist:\n {dnfe}");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(listView1.Items[0].SubItems[0].ToString());
        }

        private void listView1_DoubleClick(object sender, EventArgs e)
        {
            textBox1.Text = "";
            if (listView1.SelectedItems.Count != 1) return;
            string test = "testfiles\\in\\" + listView1.SelectedItems[0].SubItems[1].Text;
            //MessageBox.Show(test);
            
            Process p = new Process();
            p.StartInfo.UseShellExecute = false;
            p.StartInfo.RedirectStandardOutput = true;
            p.StartInfo.FileName = "java.exe";
            p.StartInfo.WorkingDirectory = @"..\..\..\..\VeryGoodViroGame\";
            string arg = $"-jar VeryGoodViroGame.jar {test}";
            p.StartInfo.Arguments = arg;
            p.StartInfo.CreateNoWindow = true;
            try
            {
                p.Start();
                string ret = p.StandardOutput.ReadToEnd();
                
                string tout_path = "..\\..\\..\\..\\VeryGoodViroGame\\testfiles\\out\\" + listView1.SelectedItems[0].SubItems[1].Text;
                tout_path = tout_path.Replace(".tin", ".tout");
                string tout = File.ReadAllText(tout_path);

                if (String.Compare(ret, tout, CultureInfo.CurrentCulture, CompareOptions.IgnoreCase | CompareOptions.IgnoreSymbols) == 0)
                {
                    ret = ret.Replace("\n","\r\n");
                    textBox1.Text = "Successful!\r\n\r\n" + ret;
                }
                else
                {
                    ret = ret.Replace("\n", "\r\n");
                    tout = tout.Replace("\n", "\r\n");
                    string diff = "Result:\r\n" + ret + "\r\n\r\nExpected:\r\n" + tout;
                    textBox1.Text = diff;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Something went wrong:\n {ex}");
            }
        }
    }
}